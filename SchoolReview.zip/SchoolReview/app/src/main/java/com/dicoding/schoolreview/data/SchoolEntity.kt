package com.dicoding.schoolreview.data

data class SchoolEntity(
    var name: String,
    var number: String,
    var street: String,
    var imagePath: String
)
